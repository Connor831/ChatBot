print("Hello user")
print("I will repeat after you.")

stuff_to_echo = input("Enter something for me to repeat:")
print(stuff_to_echo)

print("You said: " + stuff_to_echo)